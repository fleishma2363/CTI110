#get hours worked
#get pay rate
#return
#calculate gross pay


def get_input():

    hours_worked = float(input( "Please enter the number of hours you have worked: " ) )

    pay_rate = float(input( "Please enter your hourly rate: $") )

    return hours_worked, pay_rate

hours, rate = get_input

def calc_gross(hours, rate):

    if hours_worked > 40:

        over_hours = hours - 40

        over_pay = over_hours * rate * 1.5

        gross_pay = 40 * rate + over_pay

        

    else:

        gross_pay = hours_worked * pay_rate

    return gross_pay

print()

gross_pay = calc_gross(hours, rate)

print("Your gross pay is: $", format(gross_pay, ",.2f"))


    


