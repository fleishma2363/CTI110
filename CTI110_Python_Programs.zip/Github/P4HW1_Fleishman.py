VehicleSpeed = float( input( " What is the speed of the vehicle in mph: " ) )

TimeTraveled = int( input( " How many hours has it tarveled?: " ) )

print()

print( "Hour", "\t Distance Traveled" )

print()

print("---------------------------")

for CurrentHour in range( 1, TimeTraveled + 1 ):

    DistanceTraveled = VehicleSpeed * CurrentHour

    print( CurrentHour, "\t", DistanceTraveled)
