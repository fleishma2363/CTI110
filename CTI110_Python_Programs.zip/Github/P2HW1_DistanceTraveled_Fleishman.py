speed = 70
print ( " in 6 hours, the car will tarvel " + str ( ( speed * 6) ) + " miles " )
print ( " in 10 hours,  the car will travel " + str ( ( speed * 10) ) + " mile " )
print ( " in 15 hours, the car will travel " + str  ( ( speed * 15) ) + " mile" )
