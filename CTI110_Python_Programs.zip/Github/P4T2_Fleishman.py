TotalDays = 7

TotalBugs = 0

for CurrentDay in range ( 1, TotalDays +1 ):

    BugsCollected= int( input( " How many bugs were collected on day " +\
                               str( CurrentDay) + ": " ) )

    TotalBugs += BugsCollected

print()

print( " The total number of bugs collected for all", TotalDays, "day is: ", \
       TotalBugs)
