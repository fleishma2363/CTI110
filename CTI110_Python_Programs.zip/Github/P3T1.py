L1= int( input( "Please enter the length of rectangle 1: ") )

W1= int( input( "Please enter the width of rectangle 1: ") )

L2= int( input( "Please enter the length of rectangle 2: ") )

W2= int( input( "Please enter the length of rectangle 2: ") )

A1= L1*W1

A2= L2*W2

if A1 > A2:
    print( "Rectangle 1 has a larger area than rectangle 2.")
elif A1 == A2:
    print( "The 2 rectangles have an equal area.")

else:
    print( " Recatngle 2 has a larger are than reactangle 1.")
