keep_going= "y"

while keep_going == "y":

    sales = float( input( " Please enter the sales amount: "))

    com_rate = float( input( " Please enter your commission rate: "))

    commission= sales * com_rate

    print()

    print( " Your commission is", commission)

    print()

    keep_going = input( " Would you like to calculate another commision? Type y if yes: ")

    print()
    
