import turtle             
win = turtle.Screen()      
Sam = turtle.Turtle()
Sam.shape("turtle")

Sam.pensize(4)            
Sam.pencolor("orange")

Sam.forward(50)         
Sam.left(90)             
Sam.forward(50)
Sam.left(90)
Sam.forward(50)
Sam.left(90)
Sam.forward(50)            

#Triangle


import turtle          
win = turtle.Screen()  
Jeff = turtle.Turtle()

Jeff.pensize(8)            
Jeff.pencolor("green")     
Jeff.shape("turtle")

Jeff.forward(100)          
Jeff.left(120)            
Jeff.forward(100)
Jeff.left(120)
Jeff.forward(100)

win.mainloop() 
