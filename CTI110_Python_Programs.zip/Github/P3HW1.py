p = int( input( " Please enter your current age: " ))

if p <= 1:
    print( " You are an infant " )
    
elif p < 13:
    print( " You are a child " )
    
elif p < 20:
    print ( " You ar a teenager " )

else:
    print ( " You are an adult " )

    
