# P1T1
# Hello world
# Aaron Fleishman
# 2/12/2018
print ('Hello world')
