print( "Please enter a positive number. In order to quit, enter a negative number.")
total = 0
userNumber = float( input( "Please enter the first number: " ) )

while userNumber > -1:

    total = total + userNumber

    userNumber = float( input( "Please enter the next number: " ) )

print()
print( " The sum of the entered numbers is: ", total)
    
