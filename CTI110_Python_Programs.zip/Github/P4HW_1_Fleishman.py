Speed = float( input( " What is the speed of the vehicle in mph? " ) )

Hour = float( input( " How many hours has it traveled? " ) )

print( "Hour \t Distance Traveled" )

print( "--------------------------" )

Distance_Traveled = Speed * Hour

print( Distance_Traveled )
