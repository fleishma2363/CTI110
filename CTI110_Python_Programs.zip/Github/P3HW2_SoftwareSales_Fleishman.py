PP = int( input( " Please enter the number of packages purchased: " ) )

P = 99.00

if PP < 10:
    discount = 0

elif PP < 20:
    discount = 0.10

elif PP < 50:
    discount = 0.20

elif PP < 100:
    discount = 0.30

else:
    discount = 0.40

S = PP * P

D = discount * S

T = S - D

print("")

print( " Total befor discount: $" + format( S, ",.2f") +\
       "\nAmount of discount: $" + format(D, ",.2f") +\
       "\nTotal after discount: $" + format(T, ",.2f"))
