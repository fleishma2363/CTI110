import turtle          
win = turtle.Screen()
Jeff = turtle.Turtle()

Jeff.pensize(8)            
Jeff.pencolor("green")     
Jeff.shape("turtle")

for j in range(3):
    
    for i in range(3):
        Jeff.forward(100)          
        Jeff.left(120)            
        Jeff.forward(100)
        Jeff.left(120)
        Jeff.forward(100)

    Jeff.forward(50)
    Jeff.left(60)
    Jeff.forward(50)
    Jeff.left(60)
    Jeff.forward(50)

win.mainloop() 
