userInteger = int( input( " Please enter a positive number number: " ) )

while userInteger < 1:

    userInteger = int( input( " Please enter a positive number: " ) )

factorial = 1

for currentNumber in range( 1, userInteger + 1 ):

    factorial *= currentNumber

print()
print( " The factorial of", userInteger, "is", factorial)
