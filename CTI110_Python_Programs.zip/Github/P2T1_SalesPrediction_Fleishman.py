print("CTI110")
print("P2T1-Sales Prediction")
print("Aaron Fleishman")
print("2/16/18")
projectedTotalSales = float (input("Please enter the projected amount" + \
                                   "of total sales: ") )
profit = 0.23 * projectedTotalSales
print( "The profit is $" + format( profit, ",.2f"))

